import 'package:flutter/material.dart';
import '../components/category_card.dart';
import '../components/categorysection.dart';
import '../models/food_category.dart';
import 'profile_screen.dart';
import 'restaurant_detail_screen.dart';
import 'search_screen.dart';
import 'favorites_screen.dart';
import 'package:recipe_app/data/favorites.dart';
import 'map_screen.dart'; // <--- ДОБАВИЛ для карты!

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;

  final List<Widget> _tabs = [
    CategorySection(categories: mockCategories),
    const PostsTab(),
    const RestaurantsTab(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Foodie's Hub"),
        backgroundColor: Colors.green,
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const SearchScreen()),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.favorite),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const FavoritesScreen()),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.map), // <--- КНОПКА карты
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const MapScreen()),
              );
            },
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: _tabs[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.category), label: 'Categories'),
          BottomNavigationBarItem(icon: Icon(Icons.article), label: 'Posts'),
          BottomNavigationBarItem(icon: Icon(Icons.restaurant), label: 'Restaurants'),
        ],
      ),
    );
  }
}

class PostsTab extends StatelessWidget {
  const PostsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final List<String> mockPosts = [
      'I just had the best sushi ever!',
      'Homemade pizza is underrated!',
      'Burger challenge at Grill House was 🔥',
    ];

    return ListView.builder(
      itemCount: mockPosts.length,
      itemBuilder: (context, index) => Card(
        margin: const EdgeInsets.all(8),
        child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.person)),
          title: Text('Friend #$index'),
          subtitle: Text(mockPosts[index]),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ProfileScreen()),
            );
          },
        ),
      ),
    );
  }
}

class RestaurantsTab extends StatefulWidget {
  const RestaurantsTab({super.key});

  @override
  State<RestaurantsTab> createState() => _RestaurantsTabState();
}

class _RestaurantsTabState extends State<RestaurantsTab> {
  final List<Map<String, dynamic>> restaurants = [
    {
      'name': 'Pizza Planet',
      'image': 'assets/pizza.jpg',
      'menu': ['Margherita', 'Pepperoni', 'Cheese Burst'],
    },
    {
      'name': 'Sushi Spot',
      'image': 'assets/sushi.jpg',
      'menu': ['Salmon Roll', 'Avocado Maki', 'Tuna Sashimi'],
    },
    {
      'name': 'Burger King',
      'image': 'assets/burger.jpg',
      'menu': ['Whopper', 'Cheeseburger', 'Fries'],
    },
  ];

  void _toggleFavorite(Map<String, dynamic> restaurant) {
    final exists = favoriteRestaurants.any((r) => r['name'] == restaurant['name']);
    setState(() {
      if (exists) {
        favoriteRestaurants.removeWhere((r) => r['name'] == restaurant['name']);
      } else {
        favoriteRestaurants.add(restaurant);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: restaurants.map((restaurant) {
        final isFavorite = favoriteRestaurants.any((r) => r['name'] == restaurant['name']);
        return Card(
          margin: const EdgeInsets.all(8),
          child: ListTile(
            leading: const Icon(Icons.restaurant),
            title: Text(restaurant['name']),
            subtitle: const Text('Tap to view menu'),
            trailing: IconButton(
              icon: Icon(
                isFavorite ? Icons.favorite : Icons.favorite_border,
                color: isFavorite ? Colors.red : null,
              ),
              onPressed: () => _toggleFavorite(restaurant),
            ),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => RestaurantDetailScreen(
                    name: restaurant['name'],
                    image: restaurant['image'],
                    menuItems: List<String>.from(restaurant['menu']),
                  ),
                ),
              );
            },
          ),
        );
      }).toList(),
    );
  }
}
